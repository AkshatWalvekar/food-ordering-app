import React from 'react';
import '../DinningOut/DinningOutStyles.css';

const DinnigOut = () => {
  return (
    <div className='absolute-center'>
      <h1>Coming Soon</h1>
    </div>
  )
}

export default DinnigOut;